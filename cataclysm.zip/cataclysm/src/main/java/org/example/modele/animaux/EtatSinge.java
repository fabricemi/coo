package org.example.modele.animaux;

public abstract class EtatSinge {
    public abstract String gererEtat();
}
