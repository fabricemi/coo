package org.example.modele.aliments;

public class Champignon extends Aliment{
}
