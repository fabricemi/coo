package org.example.modele.aliments;

import org.example.modele.Vegetaux;

public class ChampignonVenimeux extends Aliment {
}
