package org.example.modele.animaux;

import org.example.modele.ComposantJeu;
import org.example.modele.ZoneVide;

import java.util.List;
import java.util.Map;

public interface Predator {

}
