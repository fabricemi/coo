package org.example.modele;

public class ComposantJeu {

}
