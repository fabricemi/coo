package org.example.modele;

public class Vegetaux extends ComposantJeu{

}
