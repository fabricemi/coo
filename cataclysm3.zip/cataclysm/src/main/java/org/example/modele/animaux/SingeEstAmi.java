package org.example.modele.animaux;

import org.example.modele.Colors;
import org.example.modele.ComposantJeu;

import java.util.List;
import java.util.Map;

public class SingeEstAmi extends EtatSinge{


    @Override
    public void deplacer(Singe singe,Map<Integer, List<ComposantJeu>> matrice) {

    }

}
