package org.example.modele;

import org.example.modele.animaux.Animaux;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Buisson extends Vegetaux{

    public Buisson() {

    }



}
