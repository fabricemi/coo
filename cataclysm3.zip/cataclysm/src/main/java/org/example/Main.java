package org.example;
import org.example.controlleur.Controller;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        Controller controller=new Controller();
        controller.jouer();


        //System.out.println(new Random().nextInt(1));
   /*    A a=new A(2);
        A a1=new A(1);

        List<A> list1=new ArrayList<>();
        list1.add(0,a);
        list1.add(1,a1);
        System.out.println(list1);
        System.out.println("**************");
        list1.get(0).setNum(3);
        System.out.println(list1);

        System.out.println("**************");
        List<A> aList=new ArrayList<>();
        aList.add(a);
        System.out.println(aList);*/


    /*    System.out.println(aList);
        //aList.remove(a);
        System.out.println("******");
        System.out.println(aList);
        System.out.println(list1);*/

    }


}