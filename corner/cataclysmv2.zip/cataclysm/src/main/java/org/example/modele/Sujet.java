package org.example.modele;

public interface Sujet {


    public void attacher(Observateur o);
    public void detacher(Observateur o);

}
