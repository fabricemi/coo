package org.example.modele;

public class PetitRochet extends ComposantJeu{
}
