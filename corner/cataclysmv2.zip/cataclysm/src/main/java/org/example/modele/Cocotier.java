package org.example.modele;

public class Cocotier extends ComposantJeu {
}
