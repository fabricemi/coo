package org.example.modele;

public class Arbre extends ComposantJeu{

    public Arbre() {
    }

}
