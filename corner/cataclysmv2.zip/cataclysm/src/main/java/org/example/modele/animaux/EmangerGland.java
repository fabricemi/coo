package org.example.modele.animaux;

public class EmangerGland extends StratDepEcureil {

}
