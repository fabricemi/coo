package org.example.modele.animaux;

public class EmangeChampignon extends StratDepEcureil{

}
