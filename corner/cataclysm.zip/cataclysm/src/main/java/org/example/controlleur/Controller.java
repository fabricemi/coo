package org.example.controlleur;

import org.example.Vue.Ihm;
import org.example.modele.*;
import org.example.modele.personnages.Personnage;
import org.example.modele.themes.*;

public class Controller {
    private Theme theme;
    Jeu jeu;

    ZoneDeJeu zoneDeJeu;

    private Ihm ihm;

    public Controller() {
        ihm=new Ihm();
    }

    public void jouer(){
        String[] datas=initialiserZone();
        String them=datas[0];
        String typegen=datas[1];
        setZoneDeZeu(typegen);
        setTheme(them);

        jeu=new Jeu(zoneDeJeu);
        jeu.chargerReservePersonnage(them);

        ihm.afficher(theme.appliquerAffichage());

        while (true){
            String act=ihm.queVoulezFaire();
            setAction(act);
            jeu.deplacerAnimaux();
            jeu.mettreAjour();
            System.out.println(Personnage.getInstance().getAmis()+"           animals friends");

            ihm.afficher(theme.appliquerAffichage());

        }
    }

    public void setAction(String act){
        String dir;
        switch (act){
            case "D":
                dir= ihm.saisirDirection();
                jeu.deplacerPersonnage(dir);
                break;
            case "AA":
                dir= ihm.saisirDirection();
                jeu.apprivoiserAnimal(dir);
                break;
            case "LN":
                dir=ihm.saisirDirection();
                jeu.lancerNourriture(dir);
                break;
            case "RO":
                dir=ihm.saisirDirection();
                jeu.ramasserObjet(dir);
                break;
            case "DC":
                jeu.donnerCoup();
                break;
            default:
                throw new  RuntimeException("Défaillance controle donnée ihm : fonction queVoulezVousFaire");
        }
    }


    public String[] initialiserZone(){
        return ihm.themeModeleGeneration();
    }

    public void setTheme(String them){
        switch (them){
            case "F":
                theme=new ThemeForet(zoneDeJeu);
                break;
            case "J":
                theme=new ThemeJungle(zoneDeJeu);
                break;
            default:
                throw  new RuntimeException("thème inconnu");
        }
    }

    public void setZoneDeZeu(String typegen){
        switch (typegen){
            case "FF":
                zoneDeJeu =new ZoneDeJeuForetParFichier();
                break;
            case "NF":
                zoneDeJeu =new ZoneDeJeuForetNouvelle(80,20);
                break;
            case "NJ":
                zoneDeJeu =new ZoneDeJeuJungleNouvelle(80,20);
                break;
            case "FJ":
                zoneDeJeu =new ZoneDeJeuJungleParFichier();
                break;
            default:
                throw new RuntimeException("Mode de generation inconnu");
        }
    }





}
