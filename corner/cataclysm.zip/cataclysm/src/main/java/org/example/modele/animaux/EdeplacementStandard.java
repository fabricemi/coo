package org.example.modele.animaux;

public class EdeplacementStandard extends StratDepEcureil {

}
