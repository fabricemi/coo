package org.example.modele.animaux;

import org.example.modele.ComposantJeu;
import org.example.modele.ZoneVide;

import java.util.List;
import java.util.Map;

public abstract class StratDepEcureil {

    public boolean seDeplacer(Map<Integer, List<ComposantJeu>> matrice, String sens,Ecureil ecureil ){
        try {
            int col = ecureil.caseAmodifier(sens)[0];
            int row = ecureil.caseAmodifier(sens)[1];


            matrice.get(ecureil.getPosition().getX()).remove(ecureil.getPosition().getY());
            matrice.get(ecureil.getPosition().getX()).add(ecureil.getPosition().getY(), new ZoneVide());

            matrice.get(col).remove(row);
            matrice.get(col).add(row, ecureil);
            ecureil.setPosition(col,row);

            return true;
        }
        catch (IndexOutOfBoundsException | NullPointerException e){
            return false;
        }

    }
}
