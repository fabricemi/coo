package org.example.modele.themes;

import java.util.List;
import java.util.Map;

public class ZoneDeJeuForetParFichier extends ZoneDeJeuForet {

    @Override
    public Map<Integer, List<String>> genererMatriceCaracteres() {
        GenerateurParFichier generateurParFichier =new GenerateurParFichier("carte.txt");
        return generateurParFichier.genererMatriceCaracteres();
    }




 /*   @Override
    public Map<Integer, List<String>> genererMatriceCaracteres() {

        FileReader fileReader= null;
        try {
            fileReader = new FileReader(file);
            BufferedReader bufferedReader=new BufferedReader(fileReader);
            String lines;
            int j=0;
            while ((lines=bufferedReader.readLine())!=null){
                System.out.println(lines.length());
                List<String> list=new ArrayList<>();
                for (int i=0;i<lines.length(); i++) {
                    list.add(String.valueOf(lines.charAt(i)));
                }
                matrice.put(j, list);
                j++;
            }

            return matrice;

        } catch (IOException e){
            throw new RuntimeException(e);
        }
    }*/
}
