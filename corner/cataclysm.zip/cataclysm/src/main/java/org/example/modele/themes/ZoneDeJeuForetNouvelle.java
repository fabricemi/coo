package org.example.modele.themes;

import java.util.List;
import java.util.Map;

public class ZoneDeJeuForetNouvelle extends ZoneDeJeuForet {

    private int length;
    private int larger;
    private final String chaine="                                                          " +
            "      EAAAE                                                                        AAEAAAAAAAAB   BBBBB EEE  E         GGGGG" +
            "AAAAA                           AAAAAAA                     AAAAAAAAAAAAA" +
            "BBBBBBBBBB  C                      E                                 " +
            "                     CCC       CCAAC";

    public ZoneDeJeuForetNouvelle(int length, int larger) {
        this.length = length;
        this.larger = larger;
    }

    @Override
    public Map<Integer, List<String>> genererMatriceCaracteres() {
        GenerateurAleatoire generateurAleatoire =new GenerateurAleatoire(length,larger,chaine);
        return generateurAleatoire.genererMatriceCaracteres();
    }



/*  @Override
    public Map<Integer, List<String>> genererMatriceCaracteres() {

        for(int i=0; i<larger;i++){
            List<String> line=new ArrayList<>();
            for (int j = 0; j <length ; j++) {
                line.add(String.valueOf(l1.charAt(new Random().nextInt(l1.length()))));
            }
            matrice.put(i,line);
        }
        matrice.get((int)larger/2).remove((int) length/2);
        matrice.get((int)matrice.size()/2).add((int) length/2, "@");
        return matrice;
    }*/

}
