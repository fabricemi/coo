package org.example.modele.themes;

import org.example.modele.ComposantJeu;

import java.util.List;
import java.util.Map;

public abstract class ZoneDeJeu {

    protected Map<Integer, List<ComposantJeu>> matriceObjet;
    public abstract Map<Integer, List<ComposantJeu>> generateCarte();


    public Map<Integer, List<ComposantJeu>> getMatriceObjet() {
        /*System.out.println("est appelé *********************");
        Iterator<Map.Entry<Integer,List<ComposantJeu>>> iterator=matriceObjet.entrySet().iterator();

        List<Animaux> animaux=new ArrayList<>();

        while (iterator.hasNext()){
            List<ComposantJeu> composantJeus=iterator.next().getValue();
            for (int i = 0; i < composantJeus.size(); i++) {
                if(composantJeus.get(i) instanceof Animaux){
                    animaux.add((Animaux) composantJeus.get(i));
                }
            }

        }
        System.out.println(animaux);
        System.out.println("est appelé *********************");*/
        return matriceObjet;
    }


}
