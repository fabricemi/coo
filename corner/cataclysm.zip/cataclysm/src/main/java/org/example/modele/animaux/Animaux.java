package org.example.modele.animaux;

import org.example.modele.ComposantJeu;
import org.example.modele.Observateur;
import org.example.modele.Position;

import java.util.List;
import java.util.Map;

public abstract class Animaux extends ComposantJeu{
    protected Position position;

    public void initPosition(int x, int y) {
        this.position = new Position(x,y);
    }

    public void setPosition(int x, int y){
        this.position.x=x;
        this.position.y=y;
    }

    public Position getPosition() {
        return position;
    }

    public abstract void setEtat();

    public abstract void seDeplacer(Map<Integer, List<ComposantJeu>> matrice);

    public Integer[] caseAmodifier(String sens) {
        int x = this.getPosition().getX();
        int y = this.getPosition().getY();
        int col;
        int row;
        switch (sens) {
            case "D" -> {
                col = x;
                row = y + 1;
            }
            case "G" -> {
                col = x;
                row = y - 1;
            }
            case "H" -> {
                col = x - 1;
                row = y;
            }
            default -> {
                col = x + 1;
                row = y;
            }
        }

        return new Integer[]{col, row};
    }

}
