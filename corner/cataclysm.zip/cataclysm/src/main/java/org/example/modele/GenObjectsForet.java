package org.example.modele;

import org.example.modele.aliments.Champignon;
import org.example.modele.aliments.Gland;
import org.example.modele.animaux.Ecureil;
import org.example.modele.personnages.Personnage;

import java.util.ArrayList;
import java.util.List;

public class GenObjectsForet {

    public static List<ComposantJeu> generate(int abs,List<String> stringList){
        List<ComposantJeu> list = new ArrayList<>();
        for (int j=0;j<stringList.size();j++) {
            switch (stringList.get(j)) {
                case "@":
                    Personnage p=Personnage.getInstance();
                    p.initPosition(abs, j);
                    list.add(p);
                    break;
                case "E":
                    Ecureil ecureil=new Ecureil();
                    ecureil.initPosition(abs,j);
                    list.add(ecureil);
                    System.out.println(ecureil.getId());

                    break;
                case " ":
                    ZoneVide zoneVide=new ZoneVide();
                    zoneVide.initPosition(abs,j);
                    list.add(zoneVide);
                    break;
                case "G":
                    list.add(new Gland());
                    break;
                case "C":
                    list.add(new Champignon());
                    break;
                case "A":
                    list.add(new Arbre());
                    break;
                case "B":
                    list.add(new Buisson());
                    break;
                default:
                    throw new RuntimeException("caracteres inconnue");
            }
        }
        return list;
    }
}
