package org.example.modele.aliments;

public class Banane extends Aliment{
}
