package org.example.modele;

public interface Observateur {
    public void mettreAjouter();
}
