package org.example.modele.aliments;

import org.example.modele.ComposantJeu;

public class Aliment extends ComposantJeu {
}
