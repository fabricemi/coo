package org.example.modele;

public interface Pos {
}
