package org.example.modele.animaux;

public class Predator {
}
