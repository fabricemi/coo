package org.example.modele.aliments;

public class ChampignonVenimeux extends  Champignon{
}
