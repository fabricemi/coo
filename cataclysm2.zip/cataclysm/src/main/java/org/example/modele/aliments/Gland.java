package org.example.modele.aliments;

public class Gland extends Aliment{
}
