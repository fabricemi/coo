package org.example.modele;

public class Arbre extends Vegetaux{

    public Arbre() {
    }

}
