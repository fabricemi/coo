package org.example.modele;

import org.example.modele.aliments.Aliment;
import org.example.modele.animaux.Animaux;
import org.example.modele.animaux.Ecureil;
import org.example.modele.personnages.Personnage;

public interface Observateur {
    public void mettreAjouter();

}
