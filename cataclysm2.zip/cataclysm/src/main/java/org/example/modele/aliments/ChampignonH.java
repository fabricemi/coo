package org.example.modele.aliments;

public class ChampignonH extends Champignon{
}
