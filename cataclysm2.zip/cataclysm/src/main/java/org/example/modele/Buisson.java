package org.example.modele;

public class Buisson extends Vegetaux{
}
